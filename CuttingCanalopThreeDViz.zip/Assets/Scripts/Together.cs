using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class Together : MonoBehaviour
{
    AudioSource Audation;
    public float[] Simplation = new float[512];

    public GameObject ChangeSizeObject;
    GameObject[] SampleSize = new GameObject[512];
    public float MaxSCale;
    // Start is called before the first frame update
    void Start()
    {
        Audation = GetComponent<AudioSource>();

        for (int i = 0; i < 512; i++)
        {
            GameObject StartCollectedObjetct = (GameObject)Instantiate(ChangeSizeObject);
            StartCollectedObjetct.transform.position = this.transform.position;
            StartCollectedObjetct.transform.parent = this.transform;
            StartCollectedObjetct.name = "MusicShifter" + 1;
            this.transform.eulerAngles = new Vector3(0, -0.703125f * i, 0);
            StartCollectedObjetct.transform.position = Vector3.forward * 100;
            SampleSize[i] = StartCollectedObjetct;

        }
    }

    // Update is called once per frame
    void Update()
    {
        GetSpectrumAudioSource();

        for (int a = 0; a < 512; a++)
        {
            if (SampleSize != null)
            {
                SampleSize[a].transform.localScale = new Vector3(10, (Simplation[a] * MaxSCale) + 2, 10);
            }
        }
    }

    void GetSpectrumAudioSource()
    {
        Audation.GetSpectrumData(Simplation, 0, FFTWindow.Blackman);
    }
}
