using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateObje : MonoBehaviour
{
    public GameObject ChangeSizeObject;
    GameObject[] SampleSize = new GameObject[512];
    public float MaxSCale;

    //public GameObject Addering;
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < 512; i++)
        {
            GameObject StartCollectedObjetct = (GameObject)Instantiate(ChangeSizeObject);
            StartCollectedObjetct.transform.position = this.transform.position;
            StartCollectedObjetct.transform.parent = this.transform;
            StartCollectedObjetct.name = "MusicShifter" + 1;
            this.transform.eulerAngles = new Vector3(0, -0.703125f * i, 0);
            StartCollectedObjetct.transform.position = Vector3.forward * 100;
            SampleSize[i] = StartCollectedObjetct;

        }
    }

    // Update is called once per frame
    void Update()
    {

        for (int a = 0; a < 512; a++)
        {
            if (SampleSize != null)
            {
                //SampleSize[a].transform.localScale = new Vector3(10, (Addering.Simplation[a] * MaxSCale) + 2, 10);
            }
        }
    }
}
